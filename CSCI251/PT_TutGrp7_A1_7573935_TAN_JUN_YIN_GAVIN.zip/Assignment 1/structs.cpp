#include "structs.h"

using namespace std;

XYrange mapSize;
CityLocation cityLocation;
CloudCover cloudCover;
AtmosphericPressure atmosphericPressure;

vector<CityLocation> cityLocations_Vector;
vector<CloudCover> cloudCovers_Vector;
vector<AtmosphericPressure> atmosphericPressures_Vector;

